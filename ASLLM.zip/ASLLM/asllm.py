import logging
import random
import numpy as np
from aslib_scenario.aslib_scenario import ASlibScenario
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.utils import resample
from collections import Counter
from torch.optim.lr_scheduler import ExponentialLR
import torch.nn.init as init


from collections import Counter, OrderedDict
import scipy.io
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from torchtext.vocab import vocab, build_vocab_from_iterator
import torch
from torch import nn
from tkinter import _flatten
import torch.utils.data as Data
import time
from transformers import AutoModel, AutoTokenizer
import random
import pandas as pd
import numpy as np
import os
from torch.optim.lr_scheduler import ExponentialLR
import scipy.stats as stats
import torch.nn.functional as F

os.environ["CUDA_VISIBLE_DEVICES"] = '1'
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

alpha=0.9
beta=0.1

def generate_training_data(features, performances,algorithm_features):

    training_data = []
    training_label = []

    num_user_feature = features.shape[1]
    
    num_algorithm = performances.shape[1]

    

    for i in range(features.shape[0]):
        label_index = np.argmin(np.array(performances[i]))
        for j in range(performances.shape[1]):
            
            alg_embed_feature =  [0 for _ in range(num_algorithm)]
            alg_embed_feature[j] = 1
            training_data.append(np.append(np.append(list(features[i]),alg_embed_feature),[j]))
            if j == label_index:
                training_label.append(1)
            else:
                training_label.append(0)

    return np.array(training_data), np.array(training_label), num_user_feature, num_algorithm




def pad(x, max_l = 40):
    return x[:max_l] if len(x) > max_l else x + [0] * (max_l - len(x))

def train(train_iter, test_iter, net, loss, optimizer, device, num_epochs,num_user_feature, g_n):
    save_dir_path = 'FS_models'
    if not os.path.exists(save_dir_path):
        os.makedirs(save_dir_path)
    save_path = 'FS_models/FS_model.ckpt'


    scheduler = ExponentialLR(optimizer, gamma=0.9)
    net = net.to(device)
    print("training on", device)
    batch_count = 0
    for epoch in range(num_epochs):
        train_l_sum, train_acc_sum, n, start = 0.0, 0.0, 0, time.time()
        
        for X, y in train_iter:
            X = X.to(device)
            y = y.to(device)
            
            X = X.to(torch.float32)
            
            y_hat, p_n = net(X,num_user_feature, g_n)
            
            l = loss(y_hat, y.long())
            
            optimizer.zero_grad()
            l.backward()
            
            optimizer.step()

           
            train_l_sum += l.cpu().item()
            
            train_acc_sum += (y_hat.argmax(dim=1) == y).float().sum().cpu().item() 
            
            n += y.shape[0]
            batch_count += 1

            
        
        test_acc = evaluate_acc(test_iter, net, num_user_feature, g_n)
        print('epoch %d, loss %.4f, train acc %.3f, test acc %.3f, time %.1f sec'
              % (epoch + 1, train_l_sum / n, train_acc_sum / n, test_acc, time.time() - start))
        
        state = {
                'state_dict': net.state_dict(),
                'optimizer' : optimizer.state_dict(),
            }
        torch.save(state, save_path)
    return p_n


def train1(train_iter, test_iter, net, loss, optimizer, device, num_epochs,num_user_feature, g_n, p_n):
    scheduler = ExponentialLR(optimizer, gamma=0.9)
    net = net.to(device)
    print("training on", device)
    batch_count = 0
    for epoch in range(num_epochs):
        train_l_sum, train_acc_sum, n, start = 0.0, 0.0, 0, time.time()
        
        for X, y in train_iter:
            X = X.to(device)
            y = y.to(device)
            
            X = X.to(torch.float32)
            
            y_hat, _ = net(X,num_user_feature, g_n, p_n)
            
            l = loss(y_hat, y.long())
            
            optimizer.zero_grad()
            l.backward()
            
            optimizer.step()

            
            train_l_sum += l.cpu().item()
            
            train_acc_sum += (y_hat.argmax(dim=1) == y).float().sum().cpu().item() 
            
            n += y.shape[0]
            batch_count += 1
        
        test_acc = evaluate_acc1(test_iter, net, num_user_feature, g_n, p_n)
        print('epoch %d, loss %.4f, train acc %.3f, test acc %.3f, time %.1f sec'
              % (epoch + 1, train_l_sum / n, train_acc_sum / n, test_acc, time.time() - start))



def evaluate_acc(data_iter, net, num_user_feature, g_n, threshold=0.5,
                      device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')):
    net.eval()
    acc_sum, n = 0.0, 0
    with torch.no_grad():
        
        for X, y in data_iter:
            net.eval() 
            X = X.to(device)
            y = y.to(device)
            X = X.to(torch.float32)
            
            y_hat, p_n = net(X,num_user_feature, g_n)
            acc_sum += (y_hat.argmax(dim=1) == y).float().sum().cpu().item() 
            
            n += y.shape[0]
            net.train() 

    net.train()
    return acc_sum / n        

def evaluate_acc1(data_iter, net, num_user_feature, g_n, p_n, threshold=0.5,
                      device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')):
    net.eval()
    acc_sum, n = 0.0, 0
    with torch.no_grad():
        
        for X, y in data_iter:
            net.eval()
            X = X.to(device)
            y = y.to(device)
            X = X.to(torch.float32)
            
            y_hat, _ = net(X,num_user_feature, g_n, p_n)
            acc_sum += (y_hat.argmax(dim=1) == y).float().sum().cpu().item() 
            
            n += y.shape[0]
            net.train()

    net.train()
    return acc_sum / n  
        

class RecommendationModel(nn.Module):
    def __init__(self, num_algorithm, embed_size, num_hiddens, num_layers, algorithm_features,  num_user_feature):
        super(RecommendationModel, self).__init__()
        
        self.user = nn.Sequential(
            nn.Linear(num_user_feature, 50),
            # nn.ReLU(),
            nn.Linear(50, 10)
        )
        
        
        self.LLM_embedding = nn.Embedding.from_pretrained(algorithm_features, freeze=True)
        
        self.item_embedding = nn.Embedding(num_algorithm, embed_size)
        self.algorithm1 = nn.LSTM(input_size=embed_size, 
                                hidden_size=num_hiddens, 
                                num_layers=num_layers,
                                bidirectional=False)
        
        self.trainable_vector = nn.Parameter(torch.tensor(2*num_hiddens*[0], dtype=torch.float32, requires_grad=True))
        init.constant_(self.trainable_vector, 0.5)

        self.algorithm2 = nn.Sequential(
            nn.Linear(2*num_hiddens, 50),
            nn.ReLU(),
            nn.Linear(50, 10)
        )

        
        self.cosine_similarity = nn.CosineSimilarity()
        self.concat_mlp = nn.Sequential(
           nn.Linear(10+10+1, 10),
           nn.Linear(10, 10),
           nn.ReLU(),
           nn.Linear(10, 2)
        )
        

    def forward(self, inputs, num_user_feature, g_n):
        
        user_vector = self.user(inputs[:, :num_user_feature])
        
        item_embed = self.item_embedding(inputs[:, num_user_feature:-1].permute(1, 0).long())
        
        item_vector, _  = self.algorithm1(item_embed)
        encoding = torch.cat((item_vector[0], item_vector[-1]), -1)


        alpha_1 = torch.sigmoid(self.trainable_vector)
        alpha_0 = 1 - alpha_1
        p_n_fenzi = torch.exp((torch.log(alpha_1)+g_n)/0.1)
        p_n_fenmu = torch.exp((torch.log(alpha_1)+g_n)/0.1) + torch.exp((torch.log(alpha_0)+ 1 -g_n)/0.1)
        p_n = torch.div(p_n_fenzi,p_n_fenmu)


        LLM_embed = self.LLM_embedding(inputs[:, num_user_feature].long())
        alg_feature = alpha*encoding + beta * LLM_embed.to(torch.float32)


        item_vector = self.algorithm2(alg_feature)

        
        similarity = self.cosine_similarity(user_vector, item_vector)
        concat_input = torch.cat((user_vector, item_vector, similarity.unsqueeze(1)), dim=1)
        
        output = self.concat_mlp(concat_input)
        
        return output, p_n
        
class RecommendationModel1(nn.Module):
    def __init__(self, num_algorithm, embed_size, num_hiddens, num_layers, algorithm_features,  num_user_feature):
        super(RecommendationModel1, self).__init__()
        
        self.user = nn.Sequential(
            nn.Linear(num_user_feature, 50),
            # nn.ReLU(),
            nn.Linear(50, 10)
        )
        
        
        self.LLM_embedding = nn.Embedding.from_pretrained(algorithm_features, freeze=True)
        
        self.item_embedding = nn.Embedding(num_algorithm, embed_size)
        self.algorithm1 = nn.LSTM(input_size=embed_size, 
                                hidden_size=num_hiddens, 
                                num_layers=num_layers,
                                bidirectional=False)
        
        self.trainable_vector = nn.Parameter(torch.tensor(2*num_hiddens*[0], dtype=torch.float32, requires_grad=True))
        init.constant_(self.trainable_vector, 0.5)

        self.algorithm2 = nn.Sequential(
            nn.Linear(2*num_hiddens, 50),
            nn.ReLU(),
            nn.Linear(50, 10)
        )

        
        self.cosine_similarity = nn.CosineSimilarity()
        self.concat_mlp = nn.Sequential(
           nn.Linear(10+10+1, 10), 
           nn.Linear(10, 10),
           nn.ReLU(),
           nn.Linear(10, 2)
        )
        # self.sigmoid = nn.Sigmoid()

    def forward(self, inputs, num_user_feature, g_n, p_n):
        
        user_vector = self.user(inputs[:, :num_user_feature])
        
        item_embed = self.item_embedding(inputs[:, num_user_feature:-1].permute(1, 0).long())
        
        item_vector, _  = self.algorithm1(item_embed)
        encoding = torch.cat((item_vector[0], item_vector[-1]), -1)


        
        p_n = p_n.detach()
        top30_indices = torch.topk(p_n, k=60).indices
        p_n = torch.zeros_like(p_n)
        p_n[top30_indices] = 1
        
        encoding = torch.mul(p_n, encoding)

        LLM_embed = self.LLM_embedding(inputs[:, num_user_feature].long())
        alg_feature = alpha*encoding + beta* LLM_embed.to(torch.float32)

        item_vector = self.algorithm2(alg_feature)

        
        similarity = self.cosine_similarity(user_vector, item_vector)
        concat_input = torch.cat((user_vector, item_vector, similarity.unsqueeze(1)), dim=1)
        
        output = self.concat_mlp(concat_input)
        
        return output, p_n
        

class asllm:
    
    def __init__(self):
        self._name = 'asllm'
        self._models = {}
        self._pn = {}
        self._gn = {}
        self._imputer = SimpleImputer()
        self._scaler = StandardScaler()
        
        self._rand = random.Random(0)

    def get_name(self):
        return self._name


    def fit(self, scenario: ASlibScenario, fold: int, num_instances: int):
        
        self._num_algorithms = len(scenario.algorithms)
        self._algorithm_cutoff_time = scenario.algorithm_cutoff_time

        
        features, performances = self._resample_instances(
            scenario.feature_data.values, scenario.performance_data.values, num_instances, random_state=fold)
        features, performances = self._preprocess_scenario(
            scenario, features, performances)
        
        

        p,q = performances.shape
        for i in range(p):
            
            performances[i] = np.argsort(performances[i], axis = 0)

        
        initial_cut_AFscale = 100 

        
        model_name = "BAAI/bge-base-en"#"microsoft/codebert-base"
        model = AutoModel.from_pretrained(model_name)
        tokenizer = AutoTokenizer.from_pretrained(model_name)


        directory = '/home/xxx/WorkSpace/Alg_contents/BNSL-2016_done/code/'
        # directory = '/home/xxx/WorkSpace/Alg_contents/GLUHACK-18-ALGO_done/Code/'
        # directory = '/home/xxx/WorkSpace/Alg_contents/GLUHACK-18_done/Code/'
        # directory = '/home/xxx/WorkSpace/Alg_contents/SAT03-16_INDU_done/Solver_Description/'
        # directory = '/home/xxx/WorkSpace/Alg_contents/SAT18-EXP_done/Solver_Description/'
        # directory = '/home/xxx/WorkSpace/Alg_contents/TSP-LION2015-ALGO_done/Solver_description/'
        # directory = '/home/xxx/WorkSpace/Alg_contents/TSP-LION2015_done/Solver_description/'
        # directory = '/home/xxx/WorkSpace/Alg_contents/TTP-2016_done/code/'
        file_names = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                file_names.append(os.path.join(root, file))

       
        algorithm_features = []

        
        for code_file_path in file_names:
            with open(code_file_path, "r") as f:
                code = f.read()


            
            inputs = tokenizer(code, return_tensors="pt", padding=True, truncation=True)
            
            with torch.no_grad():
                outputs = model(**inputs)
                code_features = outputs.last_hidden_state
            code_features_buf = code_features.view(-1).tolist()
            code_features_buf = pad(code_features_buf, max_l = 512*768)
            algorithm_features.append(code_features_buf)

        algorithm_features_array = np.array(algorithm_features)
        new_shape = (len(file_names), initial_cut_AFscale)
        reshaped_features_array = np.zeros(new_shape)
        for i in range(initial_cut_AFscale):
            start_col = i * 393216 // initial_cut_AFscale
            end_col = (i + 1) * 393216 // initial_cut_AFscale
            reshaped_features_array[:, i] = np.mean(algorithm_features_array[:, start_col:end_col], axis=1)
        algorithm_features = reshaped_features_array

        
        training_data, training_label, num_user_feature, num_algorithm = generate_training_data(features, performances, algorithm_features)
        X_train, X_test, y_train, y_test = train_test_split(training_data, training_label, test_size=0.02, random_state=42)

        
        X_train = torch.tensor(X_train)
        X_test = torch.tensor(X_test)
        y_train = torch.tensor(y_train)
        y_test = torch.tensor(y_test)
        algorithm_features = torch.tensor(algorithm_features)

        

        batch_size = 128
        train_set = Data.TensorDataset(X_train, y_train)
        test_set = Data.TensorDataset(X_test, y_test)
        train_iter = Data.DataLoader(train_set, batch_size, shuffle=True)
        test_iter = Data.DataLoader(test_set, batch_size)

        embed_size, num_hiddens, num_layers = 50, 50, 2
        


        net = RecommendationModel(num_algorithm,embed_size, num_hiddens, num_layers, algorithm_features, num_user_feature)
        net0 = RecommendationModel(num_algorithm,embed_size, num_hiddens, num_layers, algorithm_features, num_user_feature)
        net1 = RecommendationModel1(num_algorithm,embed_size, num_hiddens, num_layers, algorithm_features, num_user_feature)
        # print(net)
        self._models['net'] = net
        
        self._models['net1'] = net1
        

        lr, num_epochs = 0.0001, 100
       
        optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, net.parameters()), lr=0.001)
        optimizer1 = torch.optim.Adam(filter(lambda p: p.requires_grad, net1.parameters()), lr=0.001)
        loss = nn.CrossEntropyLoss()
        

        num_hiddens = 50
        np.random.seed(42)
        random_numbers = np.random.rand(2 * num_hiddens)
        u_n = torch.tensor(random_numbers, dtype=torch.float32).to(device)
        g_n = -torch.log(-torch.log(u_n))
        self._gn['gn'] = g_n
        print("*********************Begin Feature Selection*******************************************")
        num_epochs=2
        p_n = train(train_iter, test_iter, self._models['net'], loss, optimizer, device, num_epochs, num_user_feature, self._gn['gn'])
        print("*********************Finish Feature Selection*******************************************")
        self._pn['pn'] = p_n
        print("*********************Begin Training*******************************************")
        resume_fn = '/home/xxx/WorkSpace/TestAS/FS_models/FS_model.ckpt'
        checkpoint = torch.load(resume_fn)
        self._models['net1'].load_state_dict(checkpoint['state_dict'])
        
        num_epochs = 100
        
        train1(train_iter, test_iter, self._models['net1'], loss, optimizer1, device, num_epochs, num_user_feature, self._gn['gn'], self._pn['pn'])
        print("*********************Finish Training*******************************************")


    def predict(self, features, instance_id: int):
        assert(features.ndim == 1), '`features` must be one dimensional'
        features = np.expand_dims(features, axis=0)
        features = self._imputer.transform(features)
        features = self._scaler.transform(features)
        
        

        net = self._models['net1']

        predictions = []
        for i in range(self._num_algorithms):
            temp_fea = features
            temp_fea = list(temp_fea[0])
            num_features = len(temp_fea)

            alg_embed_feature =  [0 for _ in range(self._num_algorithms)]
            alg_embed_feature[i] = 1
            temp_fea = np.append(np.append(temp_fea,alg_embed_feature),[i])
            
            temp_fea = torch.tensor(temp_fea).to(device).unsqueeze(1).permute(1, 0)
            y_hat, _ = net(temp_fea.to(torch.float32), num_features, self._gn['gn'], self._pn['pn'])
            y_hat = F.softmax(y_hat, dim=1).cpu().tolist()[0]
            predictions.append(y_hat[1])

        selection = np.argmax(np.array(predictions))

        
        ranking = np.ones(self._num_algorithms)
        ranking[selection] = 0
        return ranking


    def _resample_instances(self, feature_data, performance_data, num_instances, random_state):
        num_instances = min(num_instances, np.size(performance_data, axis=0)) if num_instances > 0 else np.size(performance_data, axis=0)
        return resample(feature_data, performance_data, n_samples=num_instances, random_state=random_state)

    def _preprocess_scenario(self, scenario, features, performances):
        features = self._imputer.fit_transform(features)
        features = self._scaler.fit_transform(features)

        return features, performances